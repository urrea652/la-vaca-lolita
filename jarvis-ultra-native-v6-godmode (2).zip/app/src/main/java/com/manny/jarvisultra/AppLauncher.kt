package com.manny.jarvisultra

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.MediaStore
import android.util.Log

/**
 * AppLauncher - GOD MODE Application Resolver
 * Abre CUALQUIER aplicación instalada en el dispositivo Android mediante:
 * 1. Mapeo instantáneo de apps populares (WhatsApp, Bancolombia, Instagram, etc.)
 * 2. Búsqueda dinámica exhaustiva en PackageManager (QUERY_ALL_PACKAGES)
 * 3. Fallback de intents universales del sistema (Cámara, Teléfono, Mapas)
 */
object AppLauncher {

    private const val TAG = "JarvisAppLauncher"

    private val DIRECT_PACKAGES = mapOf(
        "whatsapp" to listOf("com.whatsapp", "com.whatsapp.w4b"),
        "instagram" to listOf("com.instagram.android"),
        "bancolombia" to listOf("co.com.bancolombia.movil", "co.com.bancolombia.personas"),
        "nequi" to listOf("com.nequi.MobileApp"),
        "daviplata" to listOf("co.com.davivienda.daviplata"),
        "youtube" to listOf("com.google.android.youtube"),
        "spotify" to listOf("com.spotify.music"),
        "netflix" to listOf("com.netflix.mediaclient"),
        "uber" to listOf("com.ubercab"),
        "tiktok" to listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill"),
        "maps" to listOf("com.google.android.apps.maps"),
        "mapas" to listOf("com.google.android.apps.maps"),
        "gmail" to listOf("com.google.android.gm"),
        "chrome" to listOf("com.android.chrome"),
        "facebook" to listOf("com.facebook.katana"),
        "telegram" to listOf("org.telegram.messenger")
    )

    fun launchApp(context: Context, appNameQuery: String): Boolean {
        val query = appNameQuery.trim().lowercase()
        Log.d(TAG, "Intentando abrir aplicación con query: '$query'")

        val pm = context.packageManager

        // 1. Manejo de intents directos del sistema (Cámara, Galería, etc.)
        if (query.contains("cámara") || query.contains("camara") || query.contains("camera")) {
            val cameraIntent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (cameraIntent.resolveActivity(pm) != null) {
                context.startActivity(cameraIntent)
                return true
            }
        }

        // 2. Comprobar mapeo directo
        for ((key, packages) in DIRECT_PACKAGES) {
            if (query.contains(key)) {
                for (pkg in packages) {
                    val intent = pm.getLaunchIntentForPackage(pkg)
                    if (intent != null) {
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                        context.startActivity(intent)
                        Log.d(TAG, "Lanzada app mapeada directamente: $pkg")
                        return true
                    }
                }
            }
        }

        // 3. Búsqueda dinámica universal mediante QUERY_ALL_PACKAGES
        try {
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val apps = pm.queryIntentActivities(mainIntent, 0)

            for (resolveInfo in apps) {
                val label = resolveInfo.loadLabel(pm).toString().lowercase()
                val pkgName = resolveInfo.activityInfo.packageName.lowercase()

                if (label.contains(query) || query.contains(label) || pkgName.contains(query)) {
                    val launchIntent = pm.getLaunchIntentForPackage(resolveInfo.activityInfo.packageName)
                    if (launchIntent != null) {
                        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                        context.startActivity(launchIntent)
                        Log.d(TAG, "Lanzada app por coincidencia dinámica: ${resolveInfo.activityInfo.packageName} ($label)")
                        return true
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error buscando en paquetes instalados: ${e.message}", e)
        }

        return false
    }
}