package com.manny.jarvisultra

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/**
 * JarvisOverlayView - GOD MODE Floating HUD
 * Renderiza la interfaz flotante (SYSTEM_ALERT_WINDOW) sobre cualquier aplicación
 * activa en Android para mostrar el estado de Jarvis y las respuestas en tiempo real.
 */
class JarvisOverlayView(private val context: Context) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var overlayView: View? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var autoDismissRunnable: Runnable? = null

    fun show(titleText: String, messageText: String) {
        if (!Settings.canDrawOverlays(context)) return

        if (overlayView != null) {
            updateContent(titleText, messageText)
            scheduleAutoDismiss()
            return
        }

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 80
        }

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 32, 40, 32)

            background = GradientDrawable().apply {
                setColor(0xEE090D16.toInt())
                cornerRadius = 36f
                setStroke(2, 0xFF00E5FF.toInt())
            }

            val title = TextView(context).apply {
                tag = "overlay_title"
                text = titleText
                textSize = 14f
                setTextColor(0xFF00E5FF.toInt())
                typeface = android.graphics.Typeface.MONOSPACE
            }
            addView(title)

            val message = TextView(context).apply {
                tag = "overlay_message"
                text = messageText
                textSize = 16f
                setTextColor(Color.WHITE)
                setPadding(0, 8, 0, 0)
            }
            addView(message)

            setOnClickListener {
                dismiss()
            }
        }

        overlayView = container
        try {
            windowManager.addView(overlayView, params)
            scheduleAutoDismiss()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun updateContent(titleText: String, messageText: String) {
        overlayView?.let { root ->
            val title = root.findViewWithTag<TextView>("overlay_title")
            val message = root.findViewWithTag<TextView>("overlay_message")
            title?.text = titleText
            message?.text = messageText
        }
    }

    private fun scheduleAutoDismiss() {
        autoDismissRunnable?.let { mainHandler.removeCallbacks(it) }
        autoDismissRunnable = Runnable { dismiss() }
        mainHandler.postDelayed(autoDismissRunnable!!, 6000)
    }

    fun dismiss() {
        autoDismissRunnable?.let { mainHandler.removeCallbacks(it) }
        overlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
            }
            overlayView = null
        }
    }
}