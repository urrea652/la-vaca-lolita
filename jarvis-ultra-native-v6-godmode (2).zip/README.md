# ⚡ JARVIS ULTRA NATIVE v6 GOD MODE ⚡

> Asistente de Inteligencia Artificial Nativo para Android con Wake Word 24/7 con pantalla apagada, apertura de cualquier app, Vosk offline y LLM Llama 3.2 3B.

---

## 🚀 Capacidades GOD MODE

- 🎙️ **Wake Word "Hey Manny" 24/7**: Escucha activa en reposo profundo mediante `PARTIAL_WAKE_LOCK` y `FOREGROUND_SERVICE_MICROPHONE`.
- 📱 **Apertura Universal de Apps**: Abre WhatsApp, Bancolombia, Instagram, Nequi, Cámara o cualquier app instalada por comando de voz.
- 🧠 **LLM 100% Offline (Llama 3.2 3B)**: Inferencia local sin necesidad de internet, totalmente privada y segura.
- 🗣️ **Vosk Offline ASR**: Reconocimiento de voz continuo sin enviar audio a servidores externos.
- 🪟 **Overlay Flotante**: Ventana `SYSTEM_ALERT_WINDOW` translúcida que responde encima de cualquier aplicación.
- 🔄 **Auto-Arranque (Boot)**: Se reactiva automáticamente al reiniciar o encender el celular.

---

## 🛠️ Cómo Compilar y Descargar el APK con GitHub Actions

1. Ve a [github.com/new](https://github.com/new) y crea un repositorio público o privado llamado `jarvis-ultra-native`.
2. Sube todos los archivos de esta carpeta o usa el botón **"Descargar ZIP"** de la aplicación web.
3. En tu repositorio de GitHub, entra en la pestaña **Actions**.
4. Selecciona el workflow **"Build JARVIS Ultra Native APK"** en la barra lateral izquierda.
5. Haz clic en **"Run workflow"** -> Selecciona rama `main` -> Clic en el botón verde **"Run workflow"**.
6. Espera unos minutos hasta que termine (marca verde ✅).
7. Haz clic en la ejecución completada y desplázate hasta la sección **Artifacts**.
8. Descarga el archivo `jarvis-ultra-native-v6-godmode-apk` (contiene tu APK listo para instalar).